import React from "react";
import "./NotFound.css";

const NotFound = () => {
  return (
    <div>
      <h1>NotFound</h1>
    </div>
  );
};

export default NotFound;
